﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'devtools', 'no',
{
	devTools :
	{
		title		: 'Elementinformasjon',
		dialogName	: 'Navn på dialogvindu',
		tabName		: 'Navn på fane',
		elementId	: 'Element-ID',
		elementType	: 'Elementtype'
	}
});
